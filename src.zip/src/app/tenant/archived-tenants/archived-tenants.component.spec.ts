import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivedTenantsComponent } from './archived-tenants.component';

describe('ArchivedTenantsComponent', () => {
  let component: ArchivedTenantsComponent;
  let fixture: ComponentFixture<ArchivedTenantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivedTenantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivedTenantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
