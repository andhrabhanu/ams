import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-archived-tenants',
  templateUrl: './archived-tenants.component.html',
  styleUrls: ['./archived-tenants.component.css']
})
export class ArchivedTenantsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
