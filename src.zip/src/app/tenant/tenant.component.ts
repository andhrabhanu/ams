import { Component } from '@angular/core';
@Component({
  templateUrl: 'tenant.component.html'
  })
export class TenantComponent { 
}
    