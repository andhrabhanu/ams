export class Tenant { 
	constructor(public countryId:number, public countryName:string,
            	public capital:string, public currency:string) {
	}
}
    