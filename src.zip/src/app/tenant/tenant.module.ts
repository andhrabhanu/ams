import { NgModule }   from '@angular/core';
import { CommonModule }   from '@angular/common';
import { ReactiveFormsModule,FormControl, FormGroup,FormsModule }    from '@angular/forms';

import { TenantComponent }  from './tenant.component';

import { TenantService } from './service/tenant.service';
import { TenantRoutingModule }  from './tenant-routing.module';
import { LeasedTenantsComponent } from './leased-tenants/leased-tenants.component';
import { UnLeasedTenantsComponent } from './un-leased-tenants/un-leased-tenants.component';
import { ArchivedTenantsComponent } from './archived-tenants/archived-tenants.component';
import { AddTenantComponent } from './add-tenant/add-tenant.component';
import { DialogComponentComponent } from './dialog-component/dialog-component.component';
import { ModalModule } from 'angular2-modal';
import { OverlayRenderer, DOMOverlayRenderer, Overlay } from 'angular2-modal';
import { Modal, BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {CdkTableModule} from '@angular/cdk';
import {
  MdAutocompleteModule,
  MdButtonModule,
  MdButtonToggleModule,
  MdCardModule,
  MdCheckboxModule,
  MdChipsModule,
  MdCoreModule,
  MdDatepickerModule,
  MdDialogModule,
  MdExpansionModule,
  MdGridListModule,
  MdIconModule,
  MdInputModule,
  MdListModule,
  MdMenuModule,
  MdNativeDateModule,
  MdPaginatorModule,
  MdProgressBarModule,
  MdProgressSpinnerModule,
  MdRadioModule,
  MdRippleModule,
  MdSelectModule,
  MdSidenavModule,
  MdSliderModule,
  MdSlideToggleModule,
  MdSnackBarModule,
  MdSortModule,
  MdTableModule,
  MdTabsModule,
  MdToolbarModule,
  MdTooltipModule,
} from '@angular/material';
import { ViewTenantComponent } from './view-tenant/view-tenant.component';
import { DialogResultExampleDialog } from './view-tenant/view-tenant.component';

  const MODAL_PROVIDERS = [
    Modal,
    Overlay,
    { provide: OverlayRenderer, useClass: DOMOverlayRenderer }
  ];

@NgModule({
  imports: [     
        CommonModule,
        ReactiveFormsModule,
        TenantRoutingModule,
        ModalModule.forRoot(),
        BootstrapModalModule,
        FormsModule,
        CdkTableModule,
        MdButtonModule,
        MdButtonToggleModule,
        MdCardModule,
        MdCheckboxModule,
        MdChipsModule,
        MdCoreModule,
        MdDatepickerModule,
        MdDialogModule,
        MdExpansionModule,
        MdGridListModule,
        MdIconModule,
        MdInputModule,
        MdListModule,
        MdMenuModule,
        MdNativeDateModule,
        MdPaginatorModule,
        MdProgressBarModule,
        MdProgressSpinnerModule,
        MdRadioModule,
        MdRippleModule,
        MdSelectModule,
        MdSidenavModule,
        MdSliderModule,
        MdSlideToggleModule,
        MdSnackBarModule,
        MdSortModule,
        MdTableModule,
        MdTabsModule,
        MdToolbarModule,
        MdTooltipModule,
  ], 
  entryComponents:[
    DialogResultExampleDialog
  ],
  declarations: [
		
	TenantComponent,DialogResultExampleDialog,		
  	LeasedTenantsComponent, UnLeasedTenantsComponent, ArchivedTenantsComponent, AddTenantComponent,DialogComponentComponent, ViewTenantComponent
],
  providers: [ MODAL_PROVIDERS,TenantService ]
})
export class TenantModule { }
