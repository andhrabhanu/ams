import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TenantComponent }  from './tenant.component';
import { LeasedTenantsComponent }  from './leased-tenants/leased-tenants.component';
import { UnLeasedTenantsComponent }  from './un-leased-tenants/un-leased-tenants.component';
import { ArchivedTenantsComponent }  from './archived-tenants/archived-tenants.component';
import { AddTenantComponent }  from './add-tenant/add-tenant.component';
import { ViewTenantComponent }  from './view-tenant/view-tenant.component';

/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const tenantRoutes: Routes = [
	{ 
	  path: 'tenant',
      component: TenantComponent,
	  children: 
	  [ 
			{
				path: 'leased-tenants',
				component: LeasedTenantsComponent
			},
			{
				path: 'unleased-tenants',
				component: UnLeasedTenantsComponent
			},
			{
				path: 'archieved-tenants',
				component: ArchivedTenantsComponent
			},
			{
				path: 'view-tenant/:uniqId',
				  component: ViewTenantComponent
			   },
			{
				path: 'add-tenant',
				component: AddTenantComponent
			},	
			
	    
	   		
	  ]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(tenantRoutes) ],
  exports: [ RouterModule ]
})
export class TenantRoutingModule{ }
