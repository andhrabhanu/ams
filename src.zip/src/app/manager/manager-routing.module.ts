import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent }  from './register/register.component';
import { LoginComponent }  from './login/login.component';
import { ManagerComponent }  from './manager.component';
import { DashboardComponent }  from './dashboard/dashboard.component';


/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const managerRoutes: Routes = [
	{ 
	  path: 'manager',
      component: ManagerComponent,
	  children: 
	  [ 
			
			{
				path: 'manager-register',
				component: RegisterComponent 
			},
			{
				path: 'manager-login',
				component: LoginComponent 
			},
			{
				path: 'dashboard',
				component: DashboardComponent 
			},
		
			
		]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(managerRoutes) ],
  exports: [ RouterModule ]
})
export class ManagerRoutingModule{ }
