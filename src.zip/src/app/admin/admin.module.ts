import { NgModule }   from '@angular/core';
import { CommonModule }   from '@angular/common';
import { ReactiveFormsModule,FormControl, FormGroup,FormsModule }    from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';

import { AdminComponent }  from './admin.component';
import { AdminRoutingModule }  from './admin-routing.module';

import { AdminService } from './service/admin.service';
import { AdminAccountsComponent } from './admin-accounts/admin-accounts.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { AuthorizationsComponent } from './authorizations/authorizations.component';


import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {CdkTableModule} from '@angular/cdk';
import {
  MdAutocompleteModule,
  MdButtonModule,
  MdButtonToggleModule,
  MdCardModule,
  MdCheckboxModule,
  MdChipsModule,
  MdCoreModule,
  MdDatepickerModule,
  MdDialogModule,
  MdExpansionModule,
  MdGridListModule,
  MdIconModule,
  MdInputModule,
  MdListModule,
  MdMenuModule,
  MdNativeDateModule,
  MdPaginatorModule,
  MdProgressBarModule,
  MdProgressSpinnerModule,
  MdRadioModule,
  MdRippleModule,
  MdSelectModule,
  MdSidenavModule,
  MdSliderModule,
  MdSlideToggleModule,
  MdSnackBarModule,
  MdSortModule,
  MdTableModule,
  MdTabsModule,
  MdToolbarModule,
  MdTooltipModule,
} from '@angular/material';
import { NavbarComponent } from './navbar/navbar.component';


@NgModule({
  imports: [     
    CommonModule,
    ReactiveFormsModule,
    CdkTableModule,
    MdButtonModule,
    MdButtonToggleModule,
    MdCardModule,
    MdCheckboxModule,
    MdChipsModule,
    MdCoreModule,
    MdDatepickerModule,
    MdDialogModule,
    MdExpansionModule,
    MdGridListModule,
    MdIconModule,
    MdInputModule,
    MdListModule,
    MdMenuModule,
    MdNativeDateModule,
    MdPaginatorModule,
    MdProgressBarModule,
    MdProgressSpinnerModule,
    MdRadioModule,
    MdRippleModule,
    MdSelectModule,
    MdSidenavModule,
    MdSliderModule,
    MdSlideToggleModule,
    MdSnackBarModule,
    MdSortModule,
    MdTableModule,
    MdTabsModule,
    MdToolbarModule,
    MdTooltipModule,
    FormsModule,
    AdminRoutingModule,
    FlashMessagesModule
 
  ], 
    declarations: [
        AdminComponent,
        AdminAccountsComponent,
        AddAdminComponent,
        AuthorizationsComponent,
        LoginComponent,
        RegisterComponent,
        NavbarComponent
      ],
  providers: [AdminService]
})
export class AdminModule { }
