import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorizations',
  templateUrl: './authorizations.component.html',
  styleUrls: ['./authorizations.component.css']
})
export class AuthorizationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
