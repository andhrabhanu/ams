import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent }  from './register/register.component';
import { LoginComponent }  from './login/login.component';


import { AdminComponent }  from './admin.component';
import { AdminAccountsComponent }  from './admin-accounts/admin-accounts.component';
import { AddAdminComponent }  from './add-admin/add-admin.component';
import { AuthorizationsComponent } from './authorizations/authorizations.component';


/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const tenantRoutes: Routes = [
	{ 
	  path: 'admin',
    component: AdminComponent,
	  children: 
	  [ 
			{
				path: 'admin-accounts',
				component: AdminAccountsComponent 
			},
			{
				path: 'admin-register',
				component: RegisterComponent 
			},
			{
				path: 'admin-login',
				component: LoginComponent 
			},
			{
				path: 'authorization',
				component: AuthorizationsComponent 
			},
			
		]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(tenantRoutes) ],
  exports: [ RouterModule ]
})
export class AdminRoutingModule{ }
