import { NgModule }   from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { MdButtonModule, MdCardModule, MdMenuModule, MdToolbarModule, MdIconModule } from '@angular/material';
import { HttpModule } from '@angular/http';
import { AppComponent }  from './app.component';
import { AddressComponent }  from './address.component';
import { PageNotFoundComponent }  from './page-not-found.component';

import { CountryModule }  from './country/country.module';
import 'hammerjs';
import { ModalModule } from 'angular2-modal';

import { DashboardModule }  from './dashboard/dashboard.module';
import { PropertyModule }  from './property/property.module';
import { TenantModule }  from './tenant/tenant.module';
import { RequestModule }  from './request/request.module';
import { AdminModule }  from './admin/admin.module';
import { ManagerModule }  from './manager/manager.module';
import { ManageModule }  from './manage/manage.module';

import { PersonModule }  from './person/person.module';
import { AppRoutingModule }  from './app-routing.module';
import {
  MdAutocompleteModule,
  MdButtonModule,
  MdButtonToggleModule,
  MdCardModule,
  MdCheckboxModule,
  MdChipsModule,
  MdCoreModule,
  MdDatepickerModule,
  MdDialogModule,
  MdExpansionModule,
  MdGridListModule,
  MdIconModule,
  MdInputModule,
  MdListModule,
  MdMenuModule,
  MdNativeDateModule,
  MdPaginatorModule,
  MdProgressBarModule,
  MdProgressSpinnerModule,
  MdRadioModule,
  MdRippleModule,
  MdSelectModule,
  MdSidenavModule,
  MdSliderModule,
  MdSlideToggleModule,
  MdSnackBarModule,
  MdSortModule,
  MdTableModule,
  MdTabsModule,
  MdToolbarModule,
  MdTooltipModule,
} from '@angular/material';


@NgModule({
  imports: [ 
    HttpModule,    
    BrowserModule,
    CountryModule,
    PersonModule,

    DashboardModule,
    PropertyModule,
    TenantModule,
    RequestModule,
    AdminModule,
    ManageModule,
    ManagerModule,
    
		
    AppRoutingModule,
    
    BrowserAnimationsModule,
    MdAutocompleteModule,
    MdButtonModule,
    MdButtonToggleModule,
    MdCardModule,
    MdCheckboxModule,
    MdChipsModule,
    MdCoreModule,
    MdDatepickerModule,
    MdDialogModule,
    MdExpansionModule,
    MdGridListModule,
    MdIconModule,
    MdInputModule,
    MdListModule,
    MdMenuModule,
    MdNativeDateModule,
    MdPaginatorModule,
    MdProgressBarModule,
    MdProgressSpinnerModule,
    MdRadioModule,
    MdRippleModule,
    MdSelectModule,
    MdSidenavModule,
    MdSliderModule,
    MdSlideToggleModule,
    MdSnackBarModule,
    MdSortModule,
    MdTableModule,
    MdTabsModule,
    MdToolbarModule,
    MdTooltipModule,
    
    

  ],
  
  declarations: [
        AppComponent,
		AddressComponent,
		PageNotFoundComponent
  ],
  providers: [ ],
  bootstrap: [ AppComponent ]
})


export class AppModule { }
