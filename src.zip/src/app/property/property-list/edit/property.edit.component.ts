import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import 'rxjs/add/operator/switchMap';

import { PropertyService } from '../../service/property.service';
import { Property } from '../../property';

@Component({
  templateUrl: './property.edit.component.html' 
}) 
export class PropertyEditComponent implements OnInit { 
    property: Property;
	constructor(
		private countryService: PropertyService,
		private route: ActivatedRoute,
        private router: Router) { }
		
    ngOnInit() {
      /*  this.route.params
        .switchMap((params: Params) => this.countryService.getCountry(+params['country-id']))
        .subscribe(country => {
		            this.property = country;
					this.setFormValues();
				}
		 ); */
    }	
	countryForm = new FormGroup({
	   name: new FormControl(),
	   capital: new FormControl(),
	   currency: new FormControl()
	});	
	setFormValues() {
	  /*  this.countryForm.setValue({name: this.property.countryName, 
	      capital: this.property.capital, currency: this.property.currency}); */
	}	
	onFormSubmit() {
	 /*   this.property.countryName = this.countryForm.get('name').value;
	   this.property.capital = this.countryForm.get('capital').value;
	   this.property.currency = this.countryForm.get('currency').value;
	   
	   this.countryService.updateCountry(this.property)
	     .then(() =>
    		  this.router.navigate([ '../../' ], { relativeTo: this.route })
		 ); */
	}
}