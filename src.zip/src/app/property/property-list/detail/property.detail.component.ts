import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/switchMap';

import { PropertyService } from '../../service/property.service';
import { Property } from '../../property';

@Component({
  templateUrl: './property.detail.component.html' 
}) 
export class CountryDetailComponent implements OnInit { 
    property: Property;
	constructor(
	        private propertyService: PropertyService,
			private route: ActivatedRoute) { }
    ngOnInit() {
      /*   this.route.params
            .switchMap((params: Params) => this.propertyService.getCountry(+params['country-id']))
            .subscribe(property => this.property = property); */
    }					
}
    