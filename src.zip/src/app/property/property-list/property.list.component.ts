import { Component, OnInit } from '@angular/core';

import { PropertyService } from '../service/property.service';
import { Property } from '../property';

@Component({
  templateUrl: './property.list.component.html' 
}) 
export class PropertyListComponent implements OnInit { 
  properties: Promise<Property[]>;
  constructor(private propertyService: PropertyService) {}
  ngOnInit() {
   // this.properties = this.propertyService.getCountries();
  }	
}
    