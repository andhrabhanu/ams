import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-leases',
  templateUrl: './property-leases.component.html',
  styleUrls: ['./property-leases.component.css']
})
export class PropertyLeasesComponent implements OnInit {
  images;

  constructor() {
    this.images = [
	{"url":"https://avisassets.abgemea.com/.imaging/featureImageLarge/dms/DMS/local/ZA/fleet/fleet-page/luxury-cars-feature.jpg"},
	{"url":"https://cdn3.droom.in/photos/images/drm/super-cars.png"},
	{"url":"http://static4.businessinsider.com/image/58bf0d47402a6b83038b45ff-1200/lamborghini-huracan-performante.jpg"},
	{"url":"http://i2.cdn.cnn.com/cnnnext/dam/assets/161217142430-2017-cars-ferrari-1-overlay-tease.jpg"},
	{"url":"https://www.whichcar.com.au/media/1786/lightning-mcqueen-cars.jpg?width=500&height=333.58662613981767"},
	{"url":"https://s-media-cache-ak0.pinimg.com/736x/d6/ff/b3/d6ffb3603cef27c8083a75249a75081a--coolest-cars-crazy-cars.jpg"},
/* 	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"},
	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"},
	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"},
	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"},
	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"},
	{"url":"https://media0ch-a.akamaihd.net/98/56/d372652eff6d3145861c497c1b8ef1bc.jpg"} */
      ];
   }

  ngOnInit() {
  }

}
