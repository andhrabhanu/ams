const COLORS = ['maroon', 'red', 'orange', 'yellow', 'olive', 'green', 'purple',
  'fuchsia', 'lime', 'teal', 'aqua', 'blue', 'navy', 'black', 'gray'];
const NAMES = ['Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack',
  'Charlotte', 'Theodore', 'Isla', 'Oliver', 'Isabella', 'Jasper',
  'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'];

  //Model
  export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}




import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {AllServices} from '../service/all-services';
export class ExampleDatabase {
    
    categories: any;
  dataChange: BehaviorSubject<UserData[]> = new BehaviorSubject<UserData[]>([]);
  get data(): UserData[] { return this.dataChange.value; }

  constructor(public allService: AllServices) {

    console.log('Inside Example Db');

    //Get array here
     this.allService.getCategories().then((data) => {
                    this.categories = data;

                   // console.log(data);
            //Run Foreach
            this.categories.forEach(element => {
                //console.log(''+element.name)
                    var output= {
                        id: element._id,
                        name: element.name,
                        progress: element._id,
                        color: element.name
                        }
                this.addUser(output);
               
                 });
            //console.log(output);

          
           /*   return {
                 
                    id: (this.data.length + 1).toString(),
                    name: name,
                    progress: Math.round(Math.random() * 100).toString(),
                    color: COLORS[Math.round(Math.random() * (COLORS.length - 1))]
                };  */

           
                }, (err) => {
                  //  console.log("not allowed");
                });

    

   

    
    
    //Calling Add User 100 Times
    /* for (let i = 0; i < 100; i++) {
         this.addUser();
    } */
    
    
  }
 
  addUser(output) {
    

    //This will call 100 times createNew User
    console.log('Inside Add user with Output');
    const copiedData = this.data.slice();
    copiedData.push(this.createNewUser(output));
    this.dataChange.next(copiedData);
  } 

   private createNewUser(output) {
       console.log('Inside createNewUser user with Output');
    console.log(output.name)

    return {
      id: (this.data.length + 1).toString(),
      name: output.name,
      progress: Math.round(Math.random() * 100).toString(),
      color: COLORS[Math.round(Math.random() * (COLORS.length - 1))]
    };
  } 
} 