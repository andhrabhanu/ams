import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
import { AllServices } from '../service/all-services';
import { PropertyService } from '../service/property.service';
import { Property } from '../property';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FileUploader } from 'ng2-file-upload';
import {MdSnackBar} from '@angular/material';

@Component({
  selector: 'app-add-property',
  templateUrl: './add-property.component.html',
  styleUrls: ['./add-property.component.css'],
  inputs:['activeColor','baseColor','overlayColor']
})
export class AddPropertyComponent implements OnInit {

       public userType:any;

    activeColor: string = 'green';
    baseColor: string = '#ccc';
    iconColor: string = 'green';
    borderColor: string = '#ddd';
    overlayColor: string = 'rgba(255,255,255,0.5)';
    
public uploader:FileUploader = new FileUploader({url:'http://localhost:8080/upload'}); 

    dragging: boolean = false;
    loaded: boolean = false;
    imageLoaded: boolean = false;
    imageSrc: string = '';      
   foods = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
         // manager_id = new FormControl(''); 
         // isLeased = new FormControl('0');     
          namej = new FormControl('');
           
          name = new FormControl('', [
                  Validators.required,
                  ]); 
        
          desc = new FormControl('', [
                  Validators.required
                  ]);
          address = new FormControl('', [
                  Validators.required
                  ]);

          rate = new FormControl('', [
                  Validators.required
                  ]);
          amenities = new FormControl('', [
                  Validators.required
                  ]);         
          
          
          deposit = new FormControl('', [
                  Validators.required
                  ]);

          latepenalty = new FormControl('', [
                  Validators.required
                  ]);        
          type = new FormControl('', [
                  Validators.required
                  ]);
          style = new FormControl('', [
                  Validators.required
                  ]); 
          petsAllowed = new FormControl('', [
                  Validators.required
                  ]);
          yearBuilt = new FormControl('', [
                  Validators.required
                  ]);
          size = new FormControl('', [
                  Validators.required
                  ]);
          bedrooms = new FormControl('', [
                  Validators.required
                  ]);
          bathrooms = new FormControl('', [
                  Validators.required
                  ]);
          parking = new FormControl('', [
                  Validators.required
                  ]);
          heating = new FormControl('', [
                  Validators.required
                  ]);
          hoaName = new FormControl('', [
                  Validators.required
                  ]);
          hoaAddress = new FormControl('', [
                  Validators.required
                  ]);
          hoaPhone = new FormControl('', [
                  Validators.required
                  ]);
          hoaFee = new FormControl('', [
                  Validators.required
                  ]);
          feeSchedule = new FormControl('', [
                  Validators.required
                  ]);                                      
                      
          map = new FormControl('');

        //Database Values  
        propertyForm = new FormGroup({

        //manager_id: this.manager_id,

                name: this.name,
                desc: this.desc,
                address: this.address,
                
                //isLeased:this.isLeased,
                
                rate: this.rate,
                latepenalty: this.latepenalty,
                deposit: this.deposit,
                petsAllowed: this.petsAllowed,
                amenities:this.amenities,

                type: this.type,
                style: this.style,
                yearBuilt: this.yearBuilt,
                size:this.size,
                parking: this.parking,
                heating:this.heating,
                bedrooms:this.bedrooms,
                bathrooms:this.bathrooms,
                //active
                hoaName: this.hoaName,
                hoaAddress: this.hoaAddress,
                hoaPhone: this.hoaPhone,
                hoaFee: this.hoaFee,
                feeSchedule: this.feeSchedule,
                map: this.map,
}); 
  constructor(public propertyService:PropertyService,
               public route:ActivatedRoute,
               public router:Router,private _fb: FormBuilder,
               public snackBar: MdSnackBar) {
            
                //User Type for Manager 

                var manager = localStorage.getItem('manager');
                var admin = localStorage.getItem('admin');
                if(manager){
                   console.log('Manager Exists')
                        var parsing_manager  = JSON.parse(manager);
                        this.userType = parsing_manager.userType;    
                }
                if(admin){
                        console.log('Admin Exists')
                        var parsing_admin  = JSON.parse(admin);
                        this.userType = parsing_admin.userType;    
                }
                
                       
        }

  ngOnInit() {
        this.propertyForm.controls['name'].setValue('Haleem Villa');
        
        
   /*         this.propertyForm = this._fb.group({
            namej: ['', [<any>Validators.required, <any>Validators.minLength(5)]],
        
            
        });
                 (<FormControl>this.propertyForm.controls['namej'])
            .setValue('John', { onlySelf: true }); */
  }
  onFormSubmit(): void {
          
      let prop_details = {
        userType:this.userType,    
        manager_id:'Mid1',
	name: this.propertyForm.get('name').value,
	desc: this.propertyForm.get('desc').value,
	address: this.propertyForm.get('address').value,
	isLeased: '0',
	rate: this.propertyForm.get('rate').value,
	latepenalty:this.propertyForm.get('latepenalty').value,
	deposit: this.propertyForm.get('deposit').value,
	petsAllowed: this.propertyForm.get('petsAllowed').value,
	amenities: this.propertyForm.get('amenities').value,
	type: this.propertyForm.get('type').value,
	style: this.propertyForm.get('style').value,
	yearBuilt: this.propertyForm.get('yearBuilt').value,
	size: this.propertyForm.get('size').value,
	parking: this.propertyForm.get('parking').value,
	heating: this.propertyForm.get('heating').value,
	bedrooms: this.propertyForm.get('bedrooms').value,
	bathrooms: this.propertyForm.get('bathrooms').value,
	active: '1',
	hoaName: this.propertyForm.get('hoaName').value,
	hoaAddress: this.propertyForm.get('hoaAddress').value,
	hoaPhone: this.propertyForm.get('hoaPhone').value,
	hoaFee: this.propertyForm.get('hoaFee').value,
	feeSchedule: this.propertyForm.get('feeSchedule').value,
        map: this.propertyForm.get('map').value,
        

        //role: this.role
    };

    console.log(JSON.stringify(prop_details,null,4));
         

        /* this.propertyService.addProperty(prop_details).then((data) => {
                       
                          console.log('Success Created Property')
                          var message = 'Property Created'
                          this.openSnackBar(message)

                          }, (err) => {
                            console.log(err);
                            var message = 'Failed Creating'
                            this.openSnackBar(message)
                          });  */
    } 
   goBack(){
    console.log('Added Property');
  } 
   openSnackBar(message) {
        this.snackBar.open(message, 'Close', { duration: 5000});
    }

    handleDragEnter() {
        this.dragging = true;
    }
    
    handleDragLeave() {
        this.dragging = false;
    }
    
    handleDrop(e) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }
    
    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e) {
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }

        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }
    
    _handleReaderLoaded(e) {
        var reader = e.target;
        this.imageSrc = reader.result;
        this.loaded = true;
    }
    
    _setActive() {
        this.borderColor = this.activeColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.activeColor;
        }
    }
    
    _setInactive() {
        this.borderColor = this.baseColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.baseColor;
        }
    }


}
