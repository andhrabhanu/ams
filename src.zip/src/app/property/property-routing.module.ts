import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PropertyComponent }  from './property.component';
import { PropertyListComponent }  from './property-list/property.list.component';
import { LeasedPropertiesComponent }  from './leased-properties/leased-properties.component';
import { UnLeasedPropertiesComponent }  from './un-leased-properties/un-leased-properties.component';
import { AddPropertyComponent }  from './add-property/add-property.component';
import { PropertyLeasesComponent }  from './property-leases/property-leases.component';
import { ViewPropertyComponent }  from './view-property/view-property.component';
import { FileUploadComponent }  from './file-upload/file-upload.component';
import { LeasePropertyComponent }  from './lease-property/lease-property.component';
import { EditPropertyComponent }  from './edit-property/edit-property.component';
import { TableComponent }  from './table/table.component';


/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const countryRoutes: Routes = [
	{ 
	  path: 'property',
      component: PropertyComponent,
	  children: 
	  [ 
		
		{
		   path: 'file-upload',
		   component: FileUploadComponent
		},
		{
		   path: 'table',
		   component: TableComponent
		},
		 /* {
			path: 'view-property',
		   component: ViewPropertyComponent
		}, */
		{
		  path: 'lease-property/:propId',
		  component: LeasePropertyComponent },
		{
		  path: 'view-property/:uniqId',
			component: ViewPropertyComponent
		},
		{
			path: 'display-property/:uniqId',
		 component: ViewPropertyComponent }, 	   	  
		{
		   path: 'edit-property',
		   component: EditPropertyComponent
		},
		{
			path: 'leased-properties',
			component: LeasedPropertiesComponent
		},
		{
		   path: 'unleased-properties',
		   component: UnLeasedPropertiesComponent
		},
		{
		   path: 'add',
		   component: AddPropertyComponent
		},
		{
		   path: 'property-leases',
		   component: PropertyLeasesComponent
		},	
	    
	   	{
	       path: 'list',
		   component: PropertyListComponent,
		  /*  children: [
		       {
			       path: 'view/:country-id',
		           component: CountryDetailComponent
			   },
		   	   {
			       path: 'edit/:country-id',
		           component: CountryEditComponent
			   },			   
		   ] */
		}	
	  ]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(countryRoutes) ],
  exports: [ RouterModule ]
})
export class PropertyRoutingModule{ }
