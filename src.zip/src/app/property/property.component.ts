import { Component } from '@angular/core';
@Component({
  templateUrl: 'property.component.html'
  })
export class PropertyComponent { 
}
    