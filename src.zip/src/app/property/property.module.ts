import { NgModule }   from '@angular/core';
import { CommonModule }   from '@angular/common';
//import { DashboardModule }   from '../dashboard/dashboard.module';
import { ReactiveFormsModule,FormControl, FormGroup,FormsModule }    from '@angular/forms';

import { PropertyComponent }  from './property.component';
import { LeasedPropertiesComponent } from './leased-properties/leased-properties.component';
import { FileUploader } from 'ng2-file-upload';

import { PropertyListComponent }  from './property-list/property.list.component';
/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */
import { PropertyService } from './service/property.service';
import { AllServices } from './service/all-services';

import { ExampleDatabase } from './table/ExampleDatabase';
import { PropertyRoutingModule }  from './property-routing.module';
import { UnLeasedPropertiesComponent } from './un-leased-properties/un-leased-properties.component';
import { AddPropertyComponent } from './add-property/add-property.component';
import { TableComponent } from './table/table.component';
import { PropertyLeasesComponent } from './property-leases/property-leases.component';
import {CdkTableModule} from '@angular/cdk';
import {
  MdAutocompleteModule,
  MdButtonModule,
  MdButtonToggleModule,
  MdCardModule,
  MdCheckboxModule,
  MdChipsModule,
  MdCoreModule,
  MdDatepickerModule,
  MdDialogModule,
  MdExpansionModule,
  MdGridListModule,
  MdIconModule,
  MdInputModule,
  MdListModule,
  MdMenuModule,
  MdNativeDateModule,
  MdPaginatorModule,
  MdProgressBarModule,
  MdProgressSpinnerModule,
  MdRadioModule,
  MdRippleModule,
  MdSelectModule,
  MdSidenavModule,
  MdSliderModule,
  MdSlideToggleModule,
  MdSnackBarModule,
  MdSortModule,
  MdTableModule,
  MdTabsModule,
  MdToolbarModule,
  MdTooltipModule,
} from '@angular/material';
import { ViewPropertyComponent } from './view-property/view-property.component';
import { FileUploadComponent } from './file-upload/file-upload.component'; 
import { FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
import { ImageUploadComponent } from './image-upload/image-upload.component';
import { MultiImageUploadComponent } from './multi-image-upload/multi-image-upload.component';
import { ImageGalleryComponent } from './image-gallery/image-gallery.component';
import { LeasePropertyComponent } from './lease-property/lease-property.component';
import { EditPropertyComponent } from './edit-property/edit-property.component';

@NgModule({
  imports: [     
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PropertyRoutingModule,
        //DashboardModule
        CdkTableModule,
        MdButtonModule,
        MdButtonToggleModule,
        MdCardModule,
        MdCheckboxModule,
        MdChipsModule,
        MdCoreModule,
        MdDatepickerModule,
        MdDialogModule,
        MdExpansionModule,
        MdGridListModule,
        MdIconModule,
        MdInputModule,
        MdListModule,
        MdMenuModule,
        MdNativeDateModule,
        MdPaginatorModule,
        MdProgressBarModule,
        MdProgressSpinnerModule,
        MdRadioModule,
        MdRippleModule,
        MdSelectModule,
        MdSidenavModule,
        MdSliderModule,
        MdSlideToggleModule,
        MdSnackBarModule,
        MdSortModule,
        MdTableModule,
        MdTabsModule,
        MdToolbarModule,
        MdTooltipModule,
  ], 
  declarations: [
		PropertyComponent,
		PropertyListComponent,
		LeasedPropertiesComponent,
		UnLeasedPropertiesComponent,
		AddPropertyComponent,
		PropertyLeasesComponent,
		TableComponent,FileSelectDirective,
		ViewPropertyComponent,
		FileUploadComponent,
		ImageUploadComponent,
		MultiImageUploadComponent,
		ImageGalleryComponent,
		LeasePropertyComponent,
		EditPropertyComponent,
  ],
  providers: [ PropertyService,AllServices ]
})
export class PropertyModule { }
