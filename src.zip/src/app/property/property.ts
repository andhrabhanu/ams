export class Property { 
    manager_id:string;
	name: string;
	desc: string;
	address: string;
	isLeased: string;
	rate: string;
	latepenalty: string;
	deposit: string;
	petsAllowed: string;
	amenities: string;
	type: string;
	style: string;
	yearBuilt: string;
	size: string;
	parking: string;
	heating: string;
	bedrooms: string;
	bathrooms: string;
	active: string;
	hoaName: string;
	hoaAddress: string;
	hoaPhone: string;
	hoaFee: string;
	feeSchedule: string;
	map: string;
	
}
    