export class Property {
  constructor(public _id: string, public name: string) { }
}