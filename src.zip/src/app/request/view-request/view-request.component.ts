import { Component,ViewChild,Input,ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { RequestService } from '../service/request.service';

@Component({
  selector: 'app-view-request',
  templateUrl: './view-request.component.html',
  styleUrls: ['./view-request.component.css']
})
export class ViewRequestComponent implements OnInit {
  public request:any; public request_id:any; public requestTitle:any; 
  public requestText:any; public propertyName:any; public requestPriority:any; 
  public requestStatus:any; public requestDate:any; 
  
  frequestTitle = new FormControl('', [
      Validators.required,
    ]); 
  frequestPriority = new FormControl('', [
      Validators.required
      ]);  
  
  frequestStatus = new FormControl('', [
      Validators.required,
    ]);
  frequestText = new FormControl('', [
      Validators.required,
    ]); 
    
    requestForm = new FormGroup({
      frequestTitle: this.frequestTitle,
      frequestPriority: this.frequestPriority,
      frequestStatus: this.frequestStatus,
      frequestText: this.frequestText,
    
    }); 
    
  
  
  constructor(public route:ActivatedRoute,
    public requestService : RequestService,
    public router:Router) { }
    uniqId = this.route.snapshot.params['uniqId'];
   ngOnInit() {
    this.getRequest();
  }

  getRequest(){
      this.requestService.getRequestByUniqueId(this.uniqId).then((data) => {
      this.request = data;
      this.request_id = this.request._id;
      this.propertyName = this.request.propertyId.name;
      this.requestTitle = this.request.requestTitle;
      this.requestText = this.request.requestText;
      this.requestPriority = this.request.requestPriority;
      this.requestDate = this.request.requestDate;
      this.requestStatus = this.request.requestStatus;

      this.requestForm.controls['frequestTitle'].setValue(this.requestTitle);
      this.requestForm.controls['frequestPriority'].setValue(this.requestPriority);
      this.requestForm.controls['frequestStatus'].setValue(this.requestStatus);
      this.requestForm.controls['frequestText'].setValue(this.requestText);
      console.log('Request STatus '+this.requestStatus);
      }, (err) => {
        console.log(err);
    });
  }
  UpdateRequest(){
        
    let requestDetails = {
        id: this.request_id,
        requestTitle: this.requestForm.get('frequestTitle').value,
        requestText: this.requestForm.get('frequestText').value,
        requestPriority: this.requestForm.get('frequestPriority').value,
        requestStatus:this.requestForm.get('frequestStatus').value 
     };
      console.log(JSON.stringify(requestDetails,null,4));

    //Getting Form Data
    this.requestService.updateRequest(requestDetails).then((data) => {
         console.log('Updated Request of '+ requestDetails.id);
      }, (err) => {
        console.log(err);
    }); 
  }
}
