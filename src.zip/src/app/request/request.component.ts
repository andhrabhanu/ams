import { Component } from '@angular/core';
@Component({
  templateUrl: 'request.component.html'
  })
export class RequestComponent { 
}
    