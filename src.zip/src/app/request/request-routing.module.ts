import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RequestComponent }  from './request.component';
import { OpenRequestsComponent }  from './open-requests/open-requests.component';
import { ClosedRequestsComponent }  from './closed-requests/closed-requests.component';
import { AddRequestComponent }  from './add-request/add-request.component';
import { ViewRequestComponent }  from './view-request/view-request.component';
import { EditRequestComponent }  from './edit-request/edit-request.component';


/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const tenantRoutes: Routes = [
	{ 
	  path: 'request',
      component: RequestComponent,
	  children: 
	  [ 
			{
				path: 'open-requests',
				component: OpenRequestsComponent
			},
			{
				path: 'closed-requests',
				component: ClosedRequestsComponent
			},
			{
				path: 'view-request/:uniqId',
				component: ViewRequestComponent
			},
			{
				path: 'edit-request',
				component: EditRequestComponent
			},
			{
				path: 'add-request',
				component: AddRequestComponent
			},
		]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(tenantRoutes) ],
  exports: [ RouterModule ]
})
export class RequestRoutingModule{ }
