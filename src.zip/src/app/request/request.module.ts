import { NgModule }   from '@angular/core';
import { CommonModule }   from '@angular/common';
import { ReactiveFormsModule,FormControl, FormGroup,FormsModule }    from '@angular/forms';
import { RequestComponent }  from './request.component';
import { RequestRoutingModule }  from './request-routing.module';
import { RequestService } from './service/request.service';
import { OpenRequestsComponent } from './open-requests/open-requests.component';
import { ClosedRequestsComponent } from './closed-requests/closed-requests.component';
import { AddRequestComponent } from './add-request/add-request.component';
import {CdkTableModule} from '@angular/cdk';
import {
  MdAutocompleteModule,
  MdButtonModule,
  MdButtonToggleModule,
  MdCardModule,
  MdCheckboxModule,
  MdChipsModule,
  MdCoreModule,
  MdDatepickerModule,
  MdDialogModule,
  MdExpansionModule,
  MdGridListModule,
  MdIconModule,
  MdInputModule,
  MdListModule,
  MdMenuModule,
  MdNativeDateModule,
  MdPaginatorModule,
  MdProgressBarModule,
  MdProgressSpinnerModule,
  MdRadioModule,
  MdRippleModule,
  MdSelectModule,
  MdSidenavModule,
  MdSliderModule,
  MdSlideToggleModule,
  MdSnackBarModule,
  MdSortModule,
  MdTableModule,
  MdTabsModule,
  MdToolbarModule,
  MdTooltipModule,
} from '@angular/material';
import { ViewRequestComponent } from './view-request/view-request.component';
import { EditRequestComponent } from './edit-request/edit-request.component';


@NgModule({
  imports: [     
    CommonModule,
		ReactiveFormsModule,
    RequestRoutingModule,
    CdkTableModule,
    MdButtonModule,
    MdButtonToggleModule,
    MdCardModule,
    MdCheckboxModule,
    MdChipsModule,
    MdCoreModule,
    MdDatepickerModule,
    MdDialogModule,
    MdExpansionModule,
    MdGridListModule,
    MdIconModule,
    MdInputModule,
    MdListModule,
    MdMenuModule,
    MdNativeDateModule,
    MdPaginatorModule,
    MdProgressBarModule,
    MdProgressSpinnerModule,
    MdRadioModule,
    MdRippleModule,
    MdSelectModule,
    MdSidenavModule,
    MdSliderModule,
    MdSlideToggleModule,
    MdSnackBarModule,
    MdSortModule,
    MdTableModule,
    MdTabsModule,
    MdToolbarModule,
    MdTooltipModule,
    FormsModule
  ], 
    declarations: [
		  RequestComponent,
		  OpenRequestsComponent,
		  ClosedRequestsComponent,
		  AddRequestComponent,
		  ViewRequestComponent,
		  EditRequestComponent,		
  	
    ],
  providers: [RequestService]
})
export class RequestModule { }
