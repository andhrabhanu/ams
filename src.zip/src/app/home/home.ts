export class Home { 
	constructor(public countryId:number, public countryName:string,
            	public capital:string, public currency:string) {
	}
}
    