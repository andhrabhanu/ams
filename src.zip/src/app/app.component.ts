import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {AdminService} from '../app/admin/service/admin.service';
import { ManagerService } from '../app/manager/service/manager.service';
import {MdSnackBar} from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'

  
})
export class AppComponent { 
  constructor(private router: Router,
    private adminService:AdminService, private managerService:ManagerService,
    public snackBar: MdSnackBar) { }
  btnClick= function () {
      
        this.router.navigateByUrl('/dashboard');
  };
  onLogoutClick(){
    this.adminService.logout();
    this.router.navigate(['admin']);
    var message = 'Admin Logged Out';
    this.openSnackBar(message)
    return false;
  }
  onLogoutManagerClick(){
    this.managerService.logout();
    this.router.navigate(['manager']);
    var message = 'Manager Logged Out';
    this.openSnackBar(message)
    return false;

  }
  openSnackBar(message) {
    this.snackBar.open(message, 'Close', { duration: 5000});
  }
  gotoHome(){
    this.router.navigate(['/home']);
  }
  GoToManagerDashboard(){
    this.router.navigate(['/manager/dashboard']);
  }
  GoToManager(){
    this.router.navigate(['/manager']);
  }
}
    