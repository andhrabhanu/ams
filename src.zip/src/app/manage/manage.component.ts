import { Component } from '@angular/core';
@Component({
  templateUrl: 'manage.component.html'
  })
export class ManageComponent { 
}
    