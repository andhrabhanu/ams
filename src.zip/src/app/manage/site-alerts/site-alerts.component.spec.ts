import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteAlertsComponent } from './site-alerts.component';

describe('SiteAlertsComponent', () => {
  let component: SiteAlertsComponent;
  let fixture: ComponentFixture<SiteAlertsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteAlertsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteAlertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
