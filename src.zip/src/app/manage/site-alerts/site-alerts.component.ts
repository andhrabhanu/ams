import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-alerts',
  templateUrl: './site-alerts.component.html',
  styleUrls: ['./site-alerts.component.css']
})
export class SiteAlertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
