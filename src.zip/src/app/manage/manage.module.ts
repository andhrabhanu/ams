import { NgModule }   from '@angular/core';
import { CommonModule }   from '@angular/common';
import { ReactiveFormsModule }    from '@angular/forms';

import { ManageComponent }  from './manage.component';
import { ManageRoutingModule }  from './manage-routing.module';

import { ManageService } from './service/manage.service';
import { SiteAlertsComponent } from './site-alerts/site-alerts.component';
import { ReportsComponent } from './reports/reports.component';
import { FormTemplatesComponent } from './form-templates/form-templates.component';
import { SiteContentComponent } from './site-content/site-content.component';
import { SettingsComponent } from './settings/settings.component';
import { SiteLogsComponent } from './site-logs/site-logs.component';




@NgModule({
  imports: [     
    CommonModule,
		ReactiveFormsModule,
		ManageRoutingModule
  ], 
    declarations: [
        ManageComponent,
        SiteAlertsComponent,
        ReportsComponent,
        FormTemplatesComponent,
        SiteContentComponent,
        SettingsComponent,
        SiteLogsComponent
      ],
  providers: [  ]
})
export class ManageModule { }
