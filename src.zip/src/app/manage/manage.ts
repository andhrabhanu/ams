export class Manage { 
	constructor(public countryId:number, public countryName:string,
            	public capital:string, public currency:string) {
	}
}
    