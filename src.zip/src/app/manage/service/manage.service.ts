import { Injectable } from '@angular/core';

import { Manage } from '../manage';

const COUNTRIES = [
  new Manage(1, 'India', 'New Delhi', 'INR'),
  new Manage(2, 'China', 'Beijing', 'RMB')
];
let countriesPromise = Promise.resolve(COUNTRIES);

@Injectable()
export class ManageService { 
	getCountries(): Promise<Manage[]> {
	    return countriesPromise;
	}
	getCountry(id: number): Promise<Manage> {
        return this.getCountries()
            .then(countries => countries.find(country => country.countryId === id));
    }	

  
}