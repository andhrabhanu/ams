import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-content',
  templateUrl: './site-content.component.html',
  styleUrls: ['./site-content.component.css']
})
export class SiteContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
