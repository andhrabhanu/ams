import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-templates',
  templateUrl: './form-templates.component.html',
  styleUrls: ['./form-templates.component.css']
})
export class FormTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
