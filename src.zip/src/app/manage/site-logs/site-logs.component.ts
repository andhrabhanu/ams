import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-logs',
  templateUrl: './site-logs.component.html',
  styleUrls: ['./site-logs.component.css']
})
export class SiteLogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
