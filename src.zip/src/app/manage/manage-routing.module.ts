import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ManageComponent }  from './manage.component';
import { SiteAlertsComponent }  from './site-alerts/site-alerts.component';
import { ReportsComponent }  from './reports/reports.component';
import { FormTemplatesComponent }  from './form-templates/form-templates.component';
import { SiteContentComponent }  from './site-content/site-content.component';
import { SettingsComponent }  from './settings/settings.component';
import { SiteLogsComponent }  from './site-logs/site-logs.component';

/* import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
import { CountryEditComponent }  from './country-list/edit/country.edit.component'; */

const tenantRoutes: Routes = [
	{ 
	  path: 'manage',
      component: ManageComponent,
	  children: 
	  [ 
		{
		  path: 'site-alerts',
		  component: SiteAlertsComponent 
		},
		{
		  path: 'reports',
		  component: ReportsComponent 
		},
		{
		  path: 'form-templates',
		  component: FormTemplatesComponent 
		},
		{
		  path: 'site-content',
		  component: SiteContentComponent 
		},
		{
		  path: 'settings',
		  component: SettingsComponent 
		},
		{
		  path: 'sitelogs',
		  component: SiteLogsComponent 
		},
	  ]
	}  
];

@NgModule({
  imports: [ RouterModule.forChild(tenantRoutes) ],
  exports: [ RouterModule ]
})
export class ManageRoutingModule{ }
