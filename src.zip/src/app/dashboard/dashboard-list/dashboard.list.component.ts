import { Component, OnInit } from '@angular/core';

import { DashboardService } from '../service/dashboard.service';
import { Dashboard } from '../dashboard';

@Component({
  templateUrl: './dashboard.list.component.html' 
}) 
export class DashboardListComponent implements OnInit { 
  countries: Promise<Dashboard[]>;
  constructor(private dashboardService: Dashboard) {}
  ngOnInit() {
   // this.countries = this.countryService.getCountries();
  }	
}
    