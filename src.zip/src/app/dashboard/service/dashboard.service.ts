import { Injectable } from '@angular/core';

import { Dashboard } from '../dashboard';

const COUNTRIES = [
  new Dashboard(1, 'India', 'New Delhi', 'INR'),
  new Dashboard(2, 'China', 'Beijing', 'RMB')
];
let countriesPromise = Promise.resolve(COUNTRIES);

@Injectable()
export class DashboardService { 
	getCountries(): Promise<Dashboard[]> {
	    return countriesPromise;
	}
	getCountry(id: number): Promise<Dashboard> {
        return this.getCountries()
            .then(countries => countries.find(country => country.countryId === id));
    }	
    updateCountry(country: Dashboard): Promise<Dashboard> {
		return this.getCountries()
		  .then(countries => {
		        let countryObj = countries.find(ob => ob.countryId === country.countryId);
                countryObj = country;
				return countryObj;
			}
		  );
    }	
    addCountry(country: Dashboard): Promise<Dashboard> {
		return this.getCountries()
		  .then(countries => {
		     let maxIndex = countries.length - 1;
		     let countryWithMaxIndex = countries[maxIndex];
		     country.countryId = countryWithMaxIndex.countryId + 1;
		     countries.push(country);
			 return country;
		  }
		);
    }	
}